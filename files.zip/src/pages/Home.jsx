import React from "react";
import { Link } from "react-router-dom";
import produtos from "../utils/produtos";
import CupomPopup from "../components/CupomPopup";

export default function Home() {
  return (
    <div className="home">
      <CupomPopup />
      <section className="banner">
        <h1>Beleza que Transforma</h1>
        <p>Os melhores cosméticos para você. Entrega rápida e garantia total!</p>
      </section>
      <h2>Destaques</h2>
      <div className="produtos-lista">
        {produtos.slice(0, 4).map(prod => (
          <Link to={`/produto/${prod.id}`} className="produto-card" key={prod.id}>
            <img src={prod.imagem} alt={prod.nome} />
            <h3>{prod.nome}</h3>
            <span className="preco">R$ {prod.preco.toFixed(2)}</span>
            {prod.estoque < 10 && (
              <span className="escassez">Poucas unidades!</span>
            )}
          </Link>
        ))}
      </div>
    </div>
  );
}