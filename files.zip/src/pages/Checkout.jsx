import React, { useState } from "react";
import { useNavigate } from "react-router-dom";

export default function Checkout() {
  const [nome, setNome] = useState("");
  const [endereco, setEndereco] = useState("");
  const [pagamento, setPagamento] = useState("pix");
  const [cupom, setCupom] = useState("");
  const navigate = useNavigate();

  function handleSubmit(e) {
    e.preventDefault();
    // Simular pagamento e limpar carrinho
    localStorage.removeItem("carrinho");
    navigate("/confirmacao");
  }

  return (
    <div className="checkout">
      <h1>Finalizar compra</h1>
      <form onSubmit={handleSubmit}>
        <label>
          Nome completo:
          <input value={nome} onChange={e => setNome(e.target.value)} required />
        </label>
        <label>
          Endereço de entrega:
          <input value={endereco} onChange={e => setEndereco(e.target.value)} required />
        </label>
        <label>
          Método de pagamento:
          <select value={pagamento} onChange={e => setPagamento(e.target.value)}>
            <option value="pix">Pix</option>
            <option value="cartao">Cartão de crédito</option>
            <option value="boleto">Boleto</option>
          </select>
        </label>
        <label>
          Cupom de desconto:
          <input value={cupom} onChange={e => setCupom(e.target.value)} placeholder="BELEZA30" />
        </label>
        <button className="comprar" type="submit">Comprar agora</button>
      </form>
    </div>
  );
}