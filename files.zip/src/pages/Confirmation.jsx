import React from "react";
import { Link } from "react-router-dom";

export default function Confirmation() {
  return (
    <div className="confirmation">
      <h1>Compra realizada com sucesso!</h1>
      <p>Seu pedido foi recebido e está sendo processado. Obrigado por comprar conosco! 😊</p>
      <Link to="/">Voltar para a loja</Link>
    </div>
  );
}