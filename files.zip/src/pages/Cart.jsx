import React, { useState, useEffect } from "react";
import { useNavigate, Link } from "react-router-dom";

export default function Cart() {
  const [carrinho, setCarrinho] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    setCarrinho(JSON.parse(localStorage.getItem("carrinho") || "[]"));
  }, []);

  function remover(id) {
    const novoCarrinho = carrinho.filter(item => item.id !== id);
    setCarrinho(novoCarrinho);
    localStorage.setItem("carrinho", JSON.stringify(novoCarrinho));
  }

  function finalizar() {
    navigate("/checkout");
  }

  const total = carrinho.reduce((acc, item) => acc + item.preco * item.quantidade, 0);

  return (
    <div className="cart">
      <h1>Seu Carrinho</h1>
      {carrinho.length === 0 ? (
        <p>Seu carrinho está vazio. <Link to="/">Ver produtos</Link></p>
      ) : (
        <div>
          {carrinho.map(item => (
            <div className="cart-item" key={item.id}>
              <img src={item.imagem} alt={item.nome} width={60} />
              <div>
                <b>{item.nome}</b><br/>
                {item.quantidade} x R$ {item.preco.toFixed(2)}
              </div>
              <button onClick={() => remover(item.id)}>Remover</button>
            </div>
          ))}
          <div className="cart-total">
            <b>Total: R$ {total.toFixed(2)}</b>
          </div>
          <button className="comprar" onClick={finalizar}>Finalizar compra</button>
        </div>
      )}
    </div>
  );
}