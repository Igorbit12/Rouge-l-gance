import React, { useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import produtos from "../utils/produtos";
import Reviews from "../components/Reviews";
import OfertaRelampago from "../components/OfertaRelampago";
import Garantia from "../components/Garantia";

export default function ProductPage() {
  const { id } = useParams();
  const produto = produtos.find(p => p.id === Number(id));
  const [quantidade, setQuantidade] = useState(1);
  const navigate = useNavigate();

  if (!produto) return <div>Produto não encontrado!</div>;

  function adicionarCarrinho() {
    let carrinho = JSON.parse(localStorage.getItem("carrinho") || "[]");
    const itemExistente = carrinho.find(i => i.id === produto.id);
    if (itemExistente) {
      itemExistente.quantidade += quantidade;
    } else {
      carrinho.push({ ...produto, quantidade });
    }
    localStorage.setItem("carrinho", JSON.stringify(carrinho));
    navigate("/carrinho");
  }

  return (
    <div className="produto-page">
      <img src={produto.imagem} alt={produto.nome} className="produto-img" />
      <div className="produto-info">
        <h1>{produto.nome}</h1>
        <p>{produto.descricao}</p>
        <b className="preco">R$ {produto.preco.toFixed(2)}</b>
        {produto.estoque < 10 && (
          <span className="urgencia">Apenas {produto.estoque} em estoque!</span>
        )}
        <div className="quantidade-control">
          <button onClick={() => setQuantidade(Math.max(1, quantidade-1))}>-</button>
          <input type="number" value={quantidade} readOnly min={1} max={produto.estoque} />
          <button onClick={() => setQuantidade(Math.min(produto.estoque, quantidade+1))}>+</button>
        </div>
        <button onClick={adicionarCarrinho} className="comprar">Adicionar ao carrinho</button>
        <Garantia />
        <OfertaRelampago />
        <Reviews reviews={produto.reviews} />
      </div>
    </div>
  );
}