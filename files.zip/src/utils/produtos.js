const produtos = [
  {
    id: 1,
    nome: "Sérum Facial Premium",
    preco: 99.9,
    estoque: 7,
    descricao: "Reduza rugas e linhas finas em 7 dias. Dermatologicamente testado.",
    imagem: "/img/serum.jpg",
    reviews: [
      { user: "Maria", nota: 5, texto: "Minha pele nunca esteve tão boa!" },
      { user: "Ana", nota: 4, texto: "Gostei muito, recomendo!" }
    ]
  },
  {
    id: 2,
    nome: "Máscara Capilar Nutritiva",
    preco: 79.9,
    estoque: 12,
    descricao: "Nutrição profunda para fios sedosos e brilhantes.",
    imagem: "/img/mascara.jpg",
    reviews: [
      { user: "Paula", nota: 5, texto: "Cabelo renovado já na primeira aplicação!" }
    ]
  },
  {
    id: 3,
    nome: "Hidratante Corporal Iluminador",
    preco: 59.9,
    estoque: 22,
    descricao: "Hidratação intensa e pele iluminada todos os dias.",
    imagem: "/img/hidratante.jpg",
    reviews: []
  },
  {
    id: 4,
    nome: "Kit Spa Relaxante",
    preco: 149.9,
    estoque: 5,
    descricao: "O autocuidado completo que você merece. Inclui 5 produtos.",
    imagem: "/img/kitspa.jpg",
    reviews: [
      { user: "Fernanda", nota: 5, texto: "Presenteei minha mãe e ela amou!" }
    ]
  }
];

export default produtos;