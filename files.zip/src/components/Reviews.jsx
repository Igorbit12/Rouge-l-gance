import React from "react";

export default function Reviews({ reviews = [] }) {
  if (!reviews.length) return null;
  return (
    <div className="reviews">
      <h3>O que estão dizendo:</h3>
      {reviews.map((r, i) => (
        <div key={i} className="review">
          <b>{r.user}:</b> {r.texto} {"⭐".repeat(r.nota)}
        </div>
      ))}
    </div>
  );
}