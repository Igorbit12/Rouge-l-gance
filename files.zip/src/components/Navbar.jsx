import React from "react";
import { Link } from "react-router-dom";

export default function Navbar() {
  return (
    <nav className="navbar">
      <Link to="/" className="logo">Cosméticos Premium</Link>
      <div>
        <Link to="/carrinho" className="cart-link">🛒 Carrinho</Link>
      </div>
    </nav>
  );
}