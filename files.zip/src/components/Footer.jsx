import React from "react";

export default function Footer() {
  return (
    <footer className="footer">
      <p>
        © {new Date().getFullYear()} Cosméticos Premium. Todos os direitos reservados.
      </p>
      <div>
        <img src="/img/selos/seguro.png" alt="Site Seguro" width={90} />
        <img src="/img/selos/pagamento.png" alt="Pagamentos" width={90} />
      </div>
    </footer>
  );
}