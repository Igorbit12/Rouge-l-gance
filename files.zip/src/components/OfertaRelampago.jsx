import React, { useEffect, useState } from "react";

export default function OfertaRelampago() {
  const [segundos, setSegundos] = useState(1799); // 29:59

  useEffect(() => {
    const timer = setTimeout(() => {
      if (segundos > 0) setSegundos(segundos - 1);
    }, 1000);
    return () => clearTimeout(timer);
  }, [segundos]);

  function formatTimer(s) {
    const min = String(Math.floor(s/60)).padStart(2, "0");
    const sec = String(s%60).padStart(2, "0");
    return `${min}:${sec}`;
  }

  return (
    <div className="oferta-relampago">
      <span>Oferta relâmpago! Só hoje com 30% OFF. <b>Use o cupom: BELEZA30</b></span>
      <div className="timer">⏰ {formatTimer(segundos)}</div>
    </div>
  );
}