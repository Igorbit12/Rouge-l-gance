import React, { useState } from "react";

export default function ProductPage() {
  // Simulação de dados
  const product = {
    id: 1,
    nome: "Sérum Facial Premium",
    preco: 99.9,
    estoque: 7,
    descricao: "Reduza rugas e linhas finas em 7 dias. Dermatologicamente testado.",
    imagem: "/img/serum.jpg",
    reviews: [
      { user: "Maria", nota: 5, texto: "Minha pele nunca esteve tão boa!" },
      { user: "Ana", nota: 4, texto: "Gostei muito, recomendo!" },
    ]
  };
  const [quantidade, setQuantidade] = useState(1);

  return (
    <div className="produto-page">
      <img src={product.imagem} alt={product.nome} />
      <h1>{product.nome}</h1>
      <p>{product.descricao}</p>
      <div>
        <b>R$ {product.preco.toFixed(2)}</b>{" "}
        {product.estoque < 10 && (
          <span className="urgencia">Apenas {product.estoque} em estoque!</span>
        )}
      </div>
      <div>
        <button onClick={() => setQuantidade(Math.max(1, quantidade-1))}>-</button>
        <input type="number" value={quantidade} readOnly min={1} max={product.estoque} />
        <button onClick={() => setQuantidade(Math.min(product.estoque, quantidade+1))}>+</button>
      </div>
      <button className="comprar">Comprar agora</button>
      <div className="garantia">
        <img src="/img/selos/garantia.png" alt="Garantia" />
        <span>Garantia de satisfação ou seu dinheiro de volta por 7 dias!</span>
      </div>
      <div className="reviews">
        <h3>O que estão dizendo:</h3>
        {product.reviews.map((r, i) => (
          <div key={i}>
            <b>{r.user}:</b> {r.texto} {"⭐".repeat(r.nota)}
          </div>
        ))}
      </div>
      <div className="oferta-relampago">
        <span>Oferta relâmpago! Só hoje com 30% OFF. <b>Use o cupom: BELEZA30</b></span>
        <div className="timer">⏰ 00:29:59</div>
      </div>
    </div>
  );
}