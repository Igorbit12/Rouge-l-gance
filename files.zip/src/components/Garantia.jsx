import React from "react";

export default function Garantia() {
  return (
    <div className="garantia">
      <img src="/img/selos/garantia.png" alt="Garantia" width={80} style={{verticalAlign:"middle"}} />
      <span style={{marginLeft: 8}}>Satisfação garantida ou seu dinheiro de volta por 7 dias!</span>
    </div>
  );
}